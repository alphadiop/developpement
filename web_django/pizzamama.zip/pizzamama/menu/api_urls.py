from django.urls import path
from . import views
app_name="menu"
urlpatterns = [
    path("GetPizzas",views.get_api_pizzas),
]
## http://127.0.0.1:8000/menu/api/GetPizzas
