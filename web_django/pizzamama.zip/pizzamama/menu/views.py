from django.shortcuts import render
from django.http import HttpResponse
from django.core import serializers
from .models import Pizza
# Create your views here.

# faut expliquer à django qu'on va acceder à cette vue à travers
# /menu

# def index(request):
#     pizzas = Pizza.objects.all()
#     pizza_names = [pizza.nom + " : " + str(pizza.prix)+" : " for pizza in pizzas]
#     pizza_nmes_str = ", ".join(pizza_names)
#     return HttpResponse(f"les pizzas : {pizza_nmes_str}")


def index(request):
    pizzas = Pizza.objects.all().order_by('prix')
    return render(request,template_name='menu/index.html',context={'pizzas': pizzas})

def get_api_pizzas(request):
    pizzas = Pizza.objects.all().order_by('prix')
    json = serializers.serialize('json',pizzas)
    return HttpResponse(json)